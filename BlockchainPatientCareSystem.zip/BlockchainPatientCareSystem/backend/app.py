from flask import Flask, render_template, request, jsonify, session
from flask_login import LoginManager, login_required, current_user, login_user
from flask_socketio import SocketIO, emit
from .payment import PaymentService
from .chatbot import chatbot_bp
from .zkp import verify_zkp  
from fhir.resources.patient import Patient  
import os
import requests
from dotenv import load_dotenv
from hfc.fabric import Client  
import psycopg2  

load_dotenv()
app = Flask(__name__)
app.secret_key = os.getenv('JWT_SECRET', 'your-secret-key-here')
socketio = SocketIO(app)
payment_service = PaymentService()
login_manager = LoginManager()
login_manager.init_app(app)
app.register_blueprint(chatbot_bp)

# Fabric Client
fabric_client = Client(net_profile=os.getenv('FABRIC_NETWORK_PROFILE', 'network.json'))

# PostgreSQL Connection
db_conn = psycopg2.connect(
    dbname=os.getenv('DATABASE_URL').split('/')[-1],
    user=os.getenv('DATABASE_URL').split('//')[1].split(':')[0],
    password=os.getenv('DATABASE_URL').split(':')[2].split('@')[0],
    host=os.getenv('DATABASE_URL').split('@')[1].split(':')[0],
    port=os.getenv('DATABASE_URL').split(':')[-1].split('/')[0]
)

@login_manager.user_loader
def load_user(user_id):
    class User:
        def __init__(self, id, role, name):
            self.id, self.role, self.name = id, role, name
        def is_authenticated(self): return True
        def is_active(self): return True
        def is_anonymous(self): return False
        def get_id(self): return str(self.id)
    return User(user_id, session.get('role'), session.get('name'))

@app.route('/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        user_id = data.get('user_id', '1')
        role = data.get('role', 'patient')
        name = data.get('name', 'John Doe')
        token = 'dummy-jwt-token'  
        session['token'] = token
        session['user_id'] = user_id
        session['role'] = role
        session['name'] = name
        user = load_user(user_id)
        login_user(user)
        return jsonify({'token': token, 'user_id': user_id, 'role': role}), 200
    except Exception as e:
        return jsonify({'error': f"Login failed: {str(e)}"}), 400

@app.route('/payment')
@login_required
def payment():
    return render_template('payment.html', user=current_user, token=session.get('token'), user_id=session.get('user_id'))

@app.route('/api/patients/payment/process', methods=['POST'])
@login_required
def process_payment():
    try:
        data = request.get_json()
        patient_id = data['patient_id']
        amount = data['amount']
        card_details = data['card_details']
        result = payment_service.process_payment(patient_id, amount, card_details, role=current_user.role, name=current_user.name)
        return jsonify({'message': result['message'], 'data': result['data']}), 200
    except Exception as e:
        message = payment_service.get_role_message(current_user.role, "payment processing", False, current_user.name)
        return jsonify({'error': f"{message} Error: {str(e)}"}), 400

@app.route('/api/patients/insurance/upload', methods=['POST'])
@login_required
def upload_insurance():
    try:
        data = request.get_json()
        patient_id = data['patient_id']
        insurance_data = data['insurance_data']
        result = payment_service.upload_insurance(patient_id, insurance_data, role=current_user.role, name=current_user.name)
        return jsonify({'message': result['message'], 'data': result['data']}), 200
    except Exception as e:
        message = payment_service.get_role_message(current_user.role, "insurance upload", False, current_user.name)
        return jsonify({'error': message}), 400

@app.route('/api/patients/payment/history/<user_id>', methods=['GET'])
@login_required
def get_payment_history(user_id):
    try:
        result = payment_service.get_payment_history(user_id, role=current_user.role, name=current_user.name)
        return jsonify(result['data']), 200
    except Exception as e:
        message = payment_service.get_role_message(current_user.role, "payment history retrieval", False, current_user.name)
        return jsonify({'error': message}), 400

@app.route('/api/patients/appointments/<user_id>', methods=['GET'])
@login_required
def get_appointments(user_id):
    try:
        chaincode = fabric_client.get_chaincode('patientcare', 'mediNetChannel')
        response = chaincode.query('GetAppointments', [user_id])
        with db_conn.cursor() as cur:
            cur.execute("SELECT * FROM appointments WHERE user_id = %s", (user_id,))
            db_result = cur.fetchall()
        appointments = response if response else [{'id': r[0], 'date': r[1], 'doctor': r[2]} for r in db_result]
        return jsonify({'data': appointments}), 200
    except Exception as e:
        return jsonify({'error': f"Failed to fetch appointments: {str(e)}"}), 400

@app.route('/api/patients/analytics/<user_id>', methods=['GET'])
@login_required
def get_analytics(user_id):
    try:
        chaincode = fabric_client.get_chaincode('patientcare', 'mediNetChannel')
        response = chaincode.query('GetAnalytics', [user_id])
        analytics = response if response else {'records': 50, 'appointments': 10, 'health_checks': 30}
        return jsonify({'data': analytics}), 200
    except Exception as e:
        return jsonify({'error': f"Failed to fetch analytics: {str(e)}"}), 400

@app.route('/api/patients/careplan', methods=['POST'])
@login_required
def save_careplan():
    try:
        data = request.json
        # ZKP verification
        zkp_proof = data.get('zkp_proof')
        if not verify_zkp(current_user.id, zkp_proof):
            return jsonify({'error': 'ZKP verification failed'}), 403
        chaincode = fabric_client.get_chaincode('patientcare', 'mediNetChannel')
        chaincode.invoke('AddCarePlan', [current_user.id, data['carePlan']])
        result = {'message': f"Care plan saved for {current_user.name}", 'data': data['carePlan']}
        emit('careplan_update', result, broadcast=True)
        return jsonify(result), 200
    except Exception as e:
        return jsonify({'error': f"Failed to save care plan: {str(e)}"}), 400

@app.route('/api/patients/prescriptions', methods=['POST'])
@login_required
def save_prescription():
    try:
        data = request.json
        # ZKP verification
        zkp_proof = data.get('zkp_proof')
        if not verify_zkp(current_user.id, zkp_proof):
            return jsonify({'error': 'ZKP verification failed'}), 403
        chaincode = fabric_client.get_chaincode('patientcare', 'mediNetChannel')
        chaincode.invoke('AddPrescription', [current_user.id, data['prescription']])
        result = {'message': f"Prescription saved for {current_user.name}", 'data': data['prescription']}
        emit('prescription_update', result, broadcast=True)
        return jsonify(result), 200
    except Exception as e:
        return jsonify({'error': f"Failed to save prescription: {str(e)}"}), 400

# FHIR Integration
@app.route('/api/fhir/patient/<user_id>', methods=['GET'])
@login_required
def get_fhir_patient(user_id):
    try:
        chaincode = fabric_client.get_chaincode('patientcare', 'mediNetChannel')
        response = chaincode.query('GetPatientData', [user_id])
        patient_data = response if response else {'name': current_user.name, 'id': user_id}
        patient = Patient()
        patient.id = patient_data['id']
        patient.name = [{'text': patient_data['name']}]
        return jsonify(patient.as_json()), 200
    except Exception as e:
        return jsonify({'error': f"Failed to fetch FHIR patient data: {str(e)}"}), 400

@app.route('/api/privacy/anonymize', methods=['POST'])
@login_required
def anonymize_data():
    chaincode = fabric_client.get_chaincode('patientcare', 'mediNetChannel')
    chaincode.invoke('AnonymizeRecord', [current_user.id])
    return jsonify({'message': f'Data anonymized for {current_user.name}'}), 200

@app.route('/api/privacy/forget', methods=['DELETE'])
@login_required
def forget_data():
    chaincode = fabric_client.get_chaincode('patientcare', 'mediNetChannel')
    chaincode.invoke('DeleteRecord', [current_user.id])
    return jsonify({'message': f'Data erased for {current_user.name}'}), 200

@socketio.on('connect')
def handle_connect():
    emit('message', {'data': f"Connected to MediNet as {current_user.role}"})

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5005)