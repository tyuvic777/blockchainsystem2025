from flask import Flask, render_template, request, jsonify, session
from flask_login import login_required, current_user
from .payment import PaymentService  
import os
import requests
from dotenv import load_dotenv

load_dotenv()
app = Flask(__name__)
payment_service = PaymentService()


@app.route('/payment')
@login_required
def payment():
    return render_template('payment.html', user=current_user, token=session.get('token'), user_id=session.get('user_id'))

@app.route('/api/patients/payment/process', methods=['POST'])
@login_required
def process_payment():
    try:
        data = request.get_json()
        patient_id = data['patient_id']
        amount = data['amount']
        card_details = data['card_details']
        result = payment_service.process_payment(patient_id, amount, card_details, role=current_user.role, name=current_user.name)
        return jsonify({'message': result['message'], 'data': result['data']}), 200
    except Exception as e:
        message = payment_service.get_role_message(current_user.role, "payment processing", False, current_user.name)
        return jsonify({'error': f"{message} Error: {str(e)}"}), 400

@app.route('/api/patients/insurance/upload', methods=['POST'])
@login_required
def upload_insurance():
    try:
        data = request.get_json()
        patient_id = data['patient_id']
        insurance_data = data['insurance_data']
        result = payment_service.upload_insurance(patient_id, insurance_data, role=current_user.role, name=current_user.name)
        return jsonify({'message': result['message'], 'data': result['data']}), 200
    except Exception as e:
        message = payment_service.get_role_message(current_user.role, "insurance upload", False, current_user.name)
        return jsonify({'error': message}), 400

@app.route('/api/patients/payment/history/<user_id>', methods=['GET'])
@login_required
def get_payment_history(user_id):
    try:
        result = payment_service.get_payment_history(user_id, role=current_user.role, name=current_user.name)
        return jsonify(result['data']), 200
    except Exception as e:
        message = payment_service.get_role_message(current_user.role, "payment history retrieval", False, current_user.name)
        return jsonify({'error': message}), 400